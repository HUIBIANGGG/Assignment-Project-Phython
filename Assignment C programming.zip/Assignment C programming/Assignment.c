#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct attendance_course {
	char course[3][50];
	int attend[3];
	int absent[3];
};

struct attendance {
	int id;
	char name[50];
	struct attendance_course attendance;
};


struct Courses_detail{
	int Course_code;
	char course_name[70];
	int course_student_quan;
};

struct Lecturer {
	int Lec_id;
	char Lec_name[50];
	char Lec_Course[50];
};

struct User {
	int id;
	char username[50];
	char password[20];
	char usertype[50];
};

struct Course {
	char courses[3][50];
	float marks[3];
	char grades[3][3];

};

struct Students
{
	int std_id;
	char name[30];
	struct Course courses;
    float CGPA;

};


//error and existance checking 
int existance_check(FILE* F,int test);
int existance_check_cmp(FILE* GF, struct User* users);
int existance_check_cmp_lec(FILE* GF, struct User* users);
int existance_password_check(FILE* F, char password[20]);

//functions
void std();
void update_course();
void update_marks();
void define_grades();
void gradings(int x, struct Students* students);
void generate_report();
void Std_view_enrolled_course(int User_id);
void register_user();
void login();
void create_std_file();
void create_Lec_file();
void Course_add();
void assign_lecturer_course();
void Update_Course_detail();
void update_users_password();
void update_std_detail(int ID);
void update_course_attendance(int id, char course_target[50], char course_update[50]);
void attendance_record();
void Attendance(char response, struct attendance* attend, int x);
void update_course_student_detail(int ID, char course_target[50], char course_update[50]);

//functions compiled as role
void STUDENT(struct User* users);
void SYSTEM_ADMINISTRATOR(struct User* users);
void LECTURER(struct User* users);
void PROGRAMME_ADMINISTRATOR(struct User* users);

//Displaying
void display_data_all();
void display_data(int);
void display_grade_standard();
void display_lec_data();
void display_data_Enroll_Course();
void display_course_file();
void display_course_specific(int code);
void display_std_detail(int ID);
void display_attendance(int ID);
void display_attendance_all();

int main() {

	//display_data_all();
	//create_std_file();
	//display_course_file();
	//Course_add();
	//Update_Course_detail();


	
		int Quit_program, options;
	Quit_program = 1;

	while (Quit_program) {
		printf("Welcome to our System\n");
		printf("--------------------------------------\n");
		printf("Menu\n");
		printf("1.Log in\n2. Quit application\n");
		printf("--------------------------------------\n");
		printf("Option:");
		scanf("%d", &options);
		getchar();
		system("cls");
		switch (options) {
		case 1:
			login();
			continue;
		case 2:
			Quit_program = 0;
		}
		printf("Bye! see you soon ");
	}
	
	

	
	

	

	//generate_report();


	//display_grade_standard();
	// 
	//display_lec_data();
	// 
	//create_Lec_file();
	//
	//assign_lecturer_course();
	//
	//display_grade_standard();
	// 
	//create_std_file();
	// 
	//register_user();
	// 
	//define_grades();  //** cautions will clear grades in grades file!
	// 
	//std();
	// 
	//update_course();
	//update_marks();
	// 
	
	// 
	//generate_report();
	//
	//update_users_password();
	//
	//attendance_record();
	
	return 0;


}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void std() { //manually add student into student file used for testing purposes
	FILE* pf;
	pf = fopen("File_std_courses_grades_GPA.txt", "a+");
	struct Students student;
	int i, x, n;
	
	char grading[2];
	
	float total,marking;
	total = 0;

	printf("How data do you wanted to enter:");
	scanf("%d", &n);

	
	getchar();
	
	for (i = 0; i < n; i++) {

		
		printf("Enter student ID:");
		scanf("%d", &student.std_id);
		
		
		printf("Enter student ID:");
		scanf("%d", &student.std_id);

		getchar();

		printf("Enter name (Use _  as space):");
		scanf("%s", student.name);
		getchar();

		for (x = 0; x < 3; x++) {
			printf("Enter student course (Use _  as space):");
			scanf("%s", student.courses.courses[x]);
			getchar();

			printf("Enter student mark:");
			scanf("%f", &student.courses.marks[x]);
			getchar();
			
			
			gradings(x,&student);// read grade and mark range for grading
			
			
			total += student.courses.marks[x];

		}

		
		fprintf(pf, "%d %s ", student.std_id, student.name);
		for (x = 0; x < 3; x++) {
			fprintf(pf, "%s %s %.2f", student.courses.courses[x], student.courses.grades[x], student.courses.marks[x]);

		}


		student.CGPA = total / 25 / 3;
		fprintf(pf, " %.2f \n", student.CGPA);

		total = 0;
		
		
	}
	fprintf(pf,"\n", student.CGPA);
	fclose(pf);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void update_course_attendance(int id, char course_target[50], char course_update[50]) {


	struct attendance attend;
	int x;

	FILE* AF;
	AF = fopen("attendance.txt", "r");

	FILE* TEM;
	TEM = fopen("Temporary_att.txt", "w");

	while (fscanf(AF, "%d %s %s %d %d %s %d %d %s %d %d", &attend.id, attend.name, attend.attendance.course[0], &attend.attendance.attend[0], &attend.attendance.absent[0], attend.attendance.course[1], &attend.attendance.attend[1], &attend.attendance.absent[1], attend.attendance.course[2], &attend.attendance.attend[2], &attend.attendance.absent[2]) != EOF) {
		if (id == attend.id) {
			for (x = 0; x < 3; x++) {
				if (strcmp(course_target, attend.attendance.course[x]) == 0) {
					strcpy(attend.attendance.course[x], course_update);
					break;
				}
			}

		}
		fprintf(TEM, "%d %s %s %d %d %s %d %d %s %d %d\n", attend.id, attend.name, attend.attendance.course[0], attend.attendance.attend[0], attend.attendance.absent[0], attend.attendance.course[1], attend.attendance.attend[1], attend.attendance.absent[1], attend.attendance.course[2], attend.attendance.attend[2], attend.attendance.absent[2]);

	}

	fclose(AF);
	fclose(TEM);
	remove("attendance.txt");
	rename("Temporary_att.txt", "attendance.txt");

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void update_course_student_detail(int ID, char course_target[50], char course_update[50]) {


	int id, age, year;
	char name[50], course1[50], course2[50], course3[50];

	FILE* STD_DETAIL;
	STD_DETAIL = fopen("Student_Detail_File.txt", "r");
	FILE* STD_TEM;
	STD_TEM = fopen("STD_TEM.txt", "w");

	while (fscanf(STD_DETAIL, "%d %s %d %d %s %s %s", &id, name, &age, &year, course1, course2, course3) != EOF) {

		if (ID == id && strcmp(course1, course_target)==0) {
			strcpy(course1, course_update);
		}
		else if (ID == id && strcmp(course2, course_target)==0) {
			strcpy(course2, course_update);
		}
		else if (ID == id && strcmp(course3, course_target) == 0) {
			strcpy(course3, course_update);
		}


		fprintf(STD_TEM, "%d  %s  %d  %d  %s  %s  %s\n", id, name, age, year, course1, course2, course3);
	}


	fclose(STD_DETAIL);
	fclose(STD_TEM);
	remove("Student_Detail_File.txt");
	rename("STD_TEM.txt", "Student_Detail_File.txt");

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void update_course() {

	display_data_Enroll_Course();

	struct Students student;

	int Search_ID;
	char Search_Course[50],updated_course[50];

	int option, i, x;
	x = 0;
	printf("Enter the Student ID:");
	scanf("%d", &Search_ID);
	system("cls");
	display_data(Search_ID);
	getchar();


	FILE* ori = fopen("File_std_courses_grades_GPA.txt", "r");
	FILE* Tem = fopen("temporary.txt", "w");
	printf("Updating student courses\n");
	while (fscanf(ori, "%d %s %s %s %f %s %s %f %s %s %f %f", &student.std_id, student.name, student.courses.courses[0],student.courses.grades[0], &student.courses.marks[0], student.courses.courses[1], student.courses.grades[1] ,&student.courses.marks[1], student.courses.courses[2], student.courses.grades[2], &student.courses.marks[2], &student.CGPA) != EOF) {
		
		if (student.std_id == Search_ID) {
			
			printf("Which courses wanted to be update? (Use _  as space):");
			scanf("%s", Search_Course);
			getchar();
			for (x = 0; x < 3; x++) {
				
				if (strcmp(Search_Course, student.courses.courses[x]) == 0) {
					printf("Update:");
					scanf("%s", student.courses.courses[x]);
					update_course_attendance(Search_ID, Search_Course, student.courses.courses[x]);///////////functions update course in attendance file at the same time
					update_course_student_detail(Search_ID, Search_Course, student.courses.courses[x]);///////////functions update course in std_detail file at the same time
					printf("Update completed!\n");
					printf("\n");
					break;
				}
				
			}
			
		}
		
		
		fprintf(Tem, "%d %s %s %s %.2f %s %s %.2f %s %s %.2f %.2f\n", student.std_id, student.name, student.courses.courses[0], student.courses.grades[0], student.courses.marks[0], student.courses.courses[1], student.courses.grades[1], student.courses.marks[1], student.courses.courses[2], student.courses.grades[2], student.courses.marks[2], student.CGPA);
		
		
	}
	
	
	fclose(Tem);
	fclose(ori);

	remove("File_std_courses_grades_GPA.txt");
	rename("temporary.txt", "File_std_courses_grades_GPA.txt");



	printf("Check the data below\n");
	display_data(Search_ID);

}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void update_marks() {

	display_data_all();

	struct Students student;

	int Search_ID;
	char Search_Course[20];
	float new_marks, total;
	total = 0;
	new_marks = 0;

	int option, i, x;
	printf("Enter the Student ID:");
	scanf("%d", &Search_ID);
	system("cls");
	display_data(Search_ID);
	printf("\n");
	getchar();



	FILE* ori = fopen("File_std_courses_grades_GPA.txt", "r");
	FILE* Tem = fopen("temporary.txt", "w");

	printf("Updating student marks\n");

	display_grade_standard();//display grade standard

	while (fscanf(ori, "%d %s %s %s %f %s %s %f %s %s %f %f", &student.std_id, student.name, student.courses.courses[0], student.courses.grades[0], &student.courses.marks[0], student.courses.courses[1], student.courses.grades[1], &student.courses.marks[1], student.courses.courses[2], student.courses.grades[2], &student.courses.marks[2], &student.CGPA) != EOF) {

		if (student.std_id == Search_ID) {

			printf("Which courses is the mark located? (Use _  as space):");
			scanf("%s", Search_Course);
			getchar();
			for (x = 0; x < 3; x++) {
				if (strcmp(Search_Course, student.courses.courses[x]) == 0) {
					printf("Update the mark:");
					scanf("%f", &new_marks);
					getchar();
					student.courses.marks[x] = new_marks;
					gradings(x, &student);// read grade and mark range for grading
					int y = 0;
					for (y = 0; y < 3; y++) {
						total += student.courses.marks[y];
						
					}

					student.CGPA = total / 25 / 3;

					printf("Update completed!\n");
					printf("\n");
					break;
				}
				else {
					continue;
				}
			}

		}
		fprintf(Tem, "%d %s %s %s %.2f %s %s %.2f %s %s %.2f %.2f\n", student.std_id, student.name, student.courses.courses[0], student.courses.grades[0], student.courses.marks[0], student.courses.courses[1], student.courses.grades[1], student.courses.marks[1], student.courses.courses[2], student.courses.grades[2], student.courses.marks[2], student.CGPA);

		
	}

	


	fclose(Tem);
	fclose(ori);
	remove("File_std_courses_grades_GPA.txt");
	rename("temporary.txt", "File_std_courses_grades_GPA.txt");

	printf("Check the data below\n");
	display_data(Search_ID);

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void define_grades() {
	struct Grade {
		char grade[5][3];
		float top[5];
		float bottom[5];
	};

	int x;

	FILE* gf;
	gf = fopen("Grade_file.txt", "w+");

	struct Grade grading;

	printf("5 grades will be prompted, each grade have top and bottom of range:\n");


	for (x = 0; x < 5; x++) {
		printf("Enter grade %d:", x + 1);
		scanf("%s", grading.grade[x]);
		printf("Enter top range:");
		scanf("%f", &grading.top[x]);
		printf("Enter bottom range:");
		scanf("%f", &grading.bottom[x]);
		fprintf(gf, "%s %f %f\n", grading.grade[x], grading.top[x], grading.bottom[x]);
	}


	fclose(gf);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void gradings(int x, struct Students *students){

	struct Grade {
		char grade[3];
		float top;
		float bottom;
	};


	struct Grade grading;
	
	char grade[3];
	
	FILE* gf;
	gf = fopen("Grade_file.txt", "r");

	
	while (fscanf(gf, "%s %f %f", grading.grade,&grading.top, &grading.bottom) != EOF) {

		
		if (grading.top >= students->courses.marks[x] && students->courses.marks[x] >= grading.bottom) {
			
			strcpy(grade, grading.grade);
			strcpy(students->courses.grades[x], grade);
			
			break;
		}
		else {
			
			continue;
		}
	}


	fclose(gf);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Std_view_enrolled_course(int User_id) {
	struct Students student;


	int index;
	char std_name[20];
	printf("---------------------------------------------\n");
	printf("View Enrolled course:\n");

	FILE* GF = fopen("File_std_courses_grades_GPA.txt", "r");


	while (fscanf(GF, "%d %s %s %s %f %s %s %f %s %s %f %f", &student.std_id, student.name, student.courses.courses[0], student.courses.grades[0], &student.courses.marks[0], student.courses.courses[1], student.courses.grades[1], &student.courses.marks[1], student.courses.courses[2], student.courses.grades[2], &student.courses.marks[2], &student.CGPA) != EOF) {

		if (User_id == student.std_id) {
			printf("Name:%s\n", student.name);
			printf("ID:%d\n", student.std_id);
			printf("Course:\n");
			for (index = 0; index < 3; index++) {
				printf("%s ", student.courses.courses[index]);
			}


		}
		else {
			continue;
		}

		fclose(GF);

	}


}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void generate_report() {
	struct Students student;


	int ID;
	int index;
	char std_name[20];

	printf("Generate student report\n");

	FILE* GF = fopen("File_std_courses_grades_GPA.txt", "r");

	FILE* UF = fopen("Users.txt", "r");
	
	printf("Enter student ID:\n");
	scanf("%d", &ID);
	

	while (existance_check(UF,ID) == 1) {/// check if it is exist
		printf("Enter Existed student ID!\n");
		printf("Enter student ID:\n");
		scanf("%d", &ID);
	}
	fclose(UF);


	while (fscanf(GF, "%d %s %s %s %f %s %s %f %s %s %f %f", &student.std_id, student.name, student.courses.courses[0], student.courses.grades[0], &student.courses.marks[0], student.courses.courses[1], student.courses.grades[1], &student.courses.marks[1], student.courses.courses[2], student.courses.grades[2], &student.courses.marks[2], &student.CGPA) != EOF) {

		if (ID== student.std_id) {
			printf("Name:%s\n", student.name);
			printf("ID:%d\n", student.std_id);
			printf("Performance\n");
			printf("Course | Grade| Mark\n");
			for (index = 0; index < 3; index++) {
				printf("%s  | %s  | %.2f\n", student.courses.courses[index], student.courses.grades[index], student.courses.marks[index]);
			}
			printf("CGPA: %.2f", student.CGPA);


		}
		else {
			continue;
		}
		

		fclose(GF);
	
	}


}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void display_std_detail(int ID) {
	
	int id, age, year;
	char name[50],course1[50], course2[50], course3[50];

	
	FILE* STD_DETAIL;
	STD_DETAIL = fopen("Student_Detail_File.txt", "r");
	rewind(STD_DETAIL);
	printf("Student ID | Student name| Age | Year | Course\n");
	while (fscanf(STD_DETAIL,"%d %s %d %d %s %s %s", &id, name,&age, &year, course1, course2, course3 )!= EOF) {
		if (ID == id) {
			printf("%d   |   %s   |   %d   |   %d   |   %s     %s     %s", id, name, age, year, course1, course2, course3);
		}
		
	}

	fclose(STD_DETAIL);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void display_grade_standard() {
	struct Grade {
		char grade[3];
		float top;
		float bottom;
	};
	struct Grade grades;
	FILE* GF = fopen("Grade_file.txt", "r");
	printf("Grade Standard\n");
	printf("Grade |   Range   \n");
	while (fscanf(GF, "%s %f %f", grades.grade, &grades.top, &grades.bottom) != EOF) {
		printf("%s | %.2f %.2f\n", grades.grade, grades.top, grades.bottom);
	}

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void display_data_all() {

	struct Students student;
	FILE* GF = fopen("File_std_courses_grades_GPA.txt", "r");


	int index;

	while (fscanf(GF, "%d %s %s %s %f %s %s %f %s %s %f %f", &student.std_id, student.name, student.courses.courses[0], student.courses.grades[0], &student.courses.marks[0], student.courses.courses[1], student.courses.grades[1], &student.courses.marks[1], student.courses.courses[2], student.courses.grades[2], &student.courses.marks[2], &student.CGPA) != EOF) {
		printf("---------------------------------------------------\n");
		printf("Name:%s\n", student.name);
		printf("ID:%d\n", student.std_id);
		printf("Course | Grade| Mark\n");
		for (index = 0; index < 3; index++) {
			printf("%s  | %s  | %f\n", student.courses.courses[index], student.courses.grades[index], student.courses.marks[index]);
		}
		printf("CGPA: %.2f\n", student.CGPA);
		printf("---------------------------------------------------\n");

	}
	fclose(GF);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void display_data(int ID) {

	struct Students student;
	FILE* GF = fopen("File_std_courses_grades_GPA.txt", "r");


	int index;

	while (fscanf(GF, "%d %s %s %s %f %s %s %f %s %s %f %f", &student.std_id, student.name, student.courses.courses[0], student.courses.grades[0], &student.courses.marks[0], student.courses.courses[1], student.courses.grades[1], &student.courses.marks[1], student.courses.courses[2], student.courses.grades[2], &student.courses.marks[2], &student.CGPA) != EOF) {
		

		if (ID == student.std_id) {
			printf("---------------------------------------------------\n");
			printf("Name:%s\n", student.name);
			printf("ID:%d\n", student.std_id);
			printf("Course | Grade| Mark\n");
			for (index = 0; index < 3; index++) {
				printf("%s  | %s  | %f\n", student.courses.courses[index], student.courses.grades[index], student.courses.marks[index]);
			}
			printf("CGPA: %.2f\n", student.CGPA);
			printf("---------------------------------------------------\n");
		}else{
			continue;
		}
		
	}
	fclose(GF);
}
////////////////////////////////////////////////////////////////////////////////////////
void display_lec_data() {


	FILE* LF = fopen("Lecturers.txt", "r");
	struct Lecturer lecs;
	while (fscanf(LF, "%d %s %s", &lecs.Lec_id, lecs.Lec_name, lecs.Lec_Course) != EOF) {
		printf("%d %s %s\n", lecs.Lec_id, lecs.Lec_name, lecs.Lec_Course);
	}
	fclose(LF);
}
///////////////////////////////////////////////////////////////////////////////////////////
void display_data_Enroll_Course() {

	struct Students student;
	FILE* GF = fopen("File_std_courses_grades_GPA.txt", "r");

	printf("View enrolled course\n");
	int index;

	while (fscanf(GF, "%d %s %s %s %f %s %s %f %s %s %f %f", &student.std_id, student.name, student.courses.courses[0], student.courses.grades[0], &student.courses.marks[0], student.courses.courses[1], student.courses.grades[1], &student.courses.marks[1], student.courses.courses[2], student.courses.grades[2], &student.courses.marks[2], &student.CGPA) != EOF) {
		printf("---------------------------------------------------\n");
		printf("Name:%s\n", student.name);
		printf("ID:%d\n", student.std_id);
		printf("Course:\n");
		for (index = 0; index < 3; index++) {
			printf("%s\n", student.courses.courses[index]);
		}
		printf("---------------------------------------------------\n");

	}
	fclose(GF);
}
//////////////////////////////////////////////////////////////////////////////////////////
int existance_check(FILE* F,int id) {
	struct User users;
	
	

	rewind(F);
	

	while (fscanf(F,"%d %s %s %s", &users.id,users.username,users.password, users.usertype) != EOF) {
		if (id == users.id) {
			printf("ID has found!\n");
			return 0;
		}
		
		
	}
	return 1;
}

///////////////////////////////////////////////////////////
int existance_password_check(FILE* F,char password[20]) {
	struct User users;
	

	rewind(F);


	while (fscanf(F, "%d %s %s %s", &users.id, users.username, users.password, users.usertype) != EOF) {
		if (strcmp(password ,users.password)==0) {
			printf("Password,must be unique!\n");
			return 0;
		}


	}
	return 1;


}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int existance_check_cmp(FILE* GF, struct User* users) {

	struct Students student;

	rewind(GF);


	while (fscanf(GF, "%d %s %s %s %f %s %s %f %s %s %f %f", &student.std_id, student.name, student.courses.courses[0], student.courses.grades[0], &student.courses.marks[0], student.courses.courses[1], student.courses.grades[1], &student.courses.marks[1], student.courses.courses[2], student.courses.grades[2], &student.courses.marks[2], &student.CGPA) != EOF) {
		if (users->id == student.std_id) {
			return 0;
		}
		
	}
	return 1;
}

int existance_check_cmp_lec(FILE* GF, struct User* users) {
	struct Lecturer lecs;

	rewind(GF);

	while (fscanf(GF, "%d %s %s", &lecs.Lec_id, lecs.Lec_name,lecs.Lec_Course) != EOF) {
		if (users->id == lecs.Lec_id) {
			return 0;
		}
		
	}
	return 1;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int integer_check(int integer) {

	if (integer != (int)integer) {

		printf("Should be integer!\n");
		return 0;
	}
	return 1;
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int float_check(float floats) {

	if (floats != (int)floats) {
		floats=getchar();
		printf("Should be floats!\n");
		return 0;
	}
	return 1;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void register_user() {
	struct User users;

	printf("User register interface:\n");

	FILE* pf;
	pf = fopen("Users.txt", "a+");
	
	int role;
	

	printf("Enter user ID, insert integer number:\n");
	scanf("%d", &users.id);

	while (existance_check(pf, users.id) == 0) {
		printf("Enter user ID, insert integer number:\n");
		scanf("%d", &users.id);
	}

	printf("Enter user name:\n");
	scanf("%s", users.username);

	printf("Enter user password(Min 3 character, Max 20 character):");
	scanf("%s", users.password);

	while (existance_password_check(pf, users.password) == 0) {
		printf("Enter user password(Min 3 character, Max 20 character):");
		scanf("%s", users.password);
	}

	printf("Role\n");
	printf("1.Student\n2.Lecturer\n3.Programme administrator\n4.System adminstrator\n");
	printf("Choose user role, insert integer number:");
	scanf("%d", &role);

	switch (role) {
	case 1:
		strcpy(users.usertype, "Student");
		break;
	case 2:
		strcpy(users.usertype, "Lecturer");
		break;
	case 3:
		strcpy(users.usertype, "Programme_Administrator");
		break;
	case 4:
		strcpy(users.usertype, "System_Administrator");
		break;
	default:
		printf("Invalid role. Please choose properly.\n");
		break;
	}
	
	fprintf(pf, "%d %s %s %s\n", users.id, users.username, users.password, users.usertype);
	
	
	
	fclose(pf);
	
	
	if (strcmp(users.usertype, "Student") == 0) {
		
		create_std_file();// create file for only student for courses ,grade and marks update
	}
	else if (strcmp(users.usertype, "Lecturer") == 0) {
		create_Lec_file();
	}
	else {
		printf("registered");
	}
	
	
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void login() {
	int user_id;
	char password[30];

	FILE* RF = fopen("Users.txt", "r");
	struct User users;


	printf("Enter user ID:\n");
	scanf("%d", &user_id);

	printf("Enter user password:");
	scanf("%s", password);

	while (fscanf(RF, "%d %s %s %s", &users.id, users.username, users.password, users.usertype) != EOF) {


		if (user_id == users.id && strcmp(password, users.password) == 0) {
			
			if (strcmp(users.usertype, "Student") == 0) {
				STUDENT(&users);
				break;
			}
			else if (strcmp(users.usertype, "System_Administrator")==0) {
				SYSTEM_ADMINISTRATOR(&users);
				break;
			}
			else if (strcmp(users.usertype, "Lecturer")==0) {
				LECTURER(&users);
				break;
			}
			else if (strcmp(users.usertype, "Programme_Administrator") == 0) {
				PROGRAMME_ADMINISTRATOR(&users);
				break;
			}
			
		}
		
		
	}
	

}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void create_std_file() {

	struct Students student;
	FILE* pf;
	pf = fopen("File_std_courses_grades_GPA.txt", "a+");////std marks grade 
	
	struct User users;

	FILE* rf;
	rf = fopen("Users.txt","r");//Scan for existed users students only

	FILE*STD_DETAIL;
	STD_DETAIL = fopen("Student_Detail_File.txt", "a+");

	struct attendance attend;
	FILE* attendance;
	attendance = fopen("attendance.txt", "a+");

	int attend_count,absent_count;

	int  x, n;
	int age, year;
	float total, marking;
	total = 0;

	while ((fscanf(rf,"%d %s %s %s", &users.id, users.username, users.password, users.usertype) != EOF)) {
		
		if (existance_check_cmp(pf, &users) == 1 /*function chechking id existance in student file*/ && strcmp(users.usertype, "Student") == 0) {
			student.std_id = users.id;
			strcpy(student.name, users.username);
			fprintf(pf, "%d %s ", student.std_id, student.name);
			fprintf(STD_DETAIL, "%d %s ", student.std_id, student.name);
			fprintf(attendance, "%d %s ", student.std_id, student.name);

			printf("Student Age:");
			scanf("%d", &age);

			printf("Student year,integer number:");
			scanf("%d", &year);

			fprintf(STD_DETAIL, "%d  %d ", age, year);

			for (x = 0; x < 3; x++) {
				strcpy(student.courses.courses[x], "-");

				student.courses.marks[x] = 0;

				gradings(x, &student);// read grade and mark range for grading

				total += student.courses.marks[x];

			}

			for (x = 0; x < 3; x++) {
				fprintf(pf, "%s %s %.2f", student.courses.courses[x], student.courses.grades[x], student.courses.marks[x]);////////////write in File_std_courses_grades_GPA.txt
				fprintf(STD_DETAIL, "%s ", student.courses.courses[x]);
				attend_count = 0;
				absent_count = 0;
				fprintf(attendance, " %s  %d  %d", student.courses.courses[x],attend_count);
			}
			fprintf(STD_DETAIL, "\n");
			fprintf(attendance, "\n");
			student.CGPA = total / 25 / 3;
			fprintf(pf, " %.2f \n", student.CGPA);////////////write in File_std_courses_grades_GPA.txt

			total = 0;

		}
	}
	fclose(pf);
	fclose(rf);
	fclose(STD_DETAIL);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void create_Lec_file() {

	struct Lecturer lecs;
	FILE* pf;
	pf = fopen("Lecturers.txt", "a+");

	struct User users;
	FILE* rf;
	rf = fopen("Users.txt", "r");


	while ((fscanf(rf, "%d %s %s %s", &users.id, users.username, users.password, users.usertype) != EOF)) {

		if (existance_check_cmp_lec(pf, &users) == 1/*function chechking id existance in lecturers*/ && strcmp(users.usertype,"Lecturer") == 0) {

			lecs.Lec_id = users.id;
			strcpy(lecs.Lec_name, users.username);
			strcpy(lecs.Lec_Course, "-");
			fprintf(pf, "%d %s %s", lecs.Lec_id, lecs.Lec_name, lecs.Lec_Course);
			fprintf(pf, "\n");
		}
	}
	fclose(pf);
	fclose(rf);

}
///////////////////////////////////////////////////////////////////////////////////////
void assign_lecturer_course() {

	struct Lecturer lecs;
	FILE* LF = fopen("Lecturers.txt", "r");
	FILE* temp = fopen("Temp.txt", "w");
	int lec_id;
	char course[50];

	display_lec_data();
	printf("Enter lecturer ID:");
	scanf("%d", &lec_id);
	getchar();
	system("cls");

	while (fscanf(LF, "%d %s %s", &lecs.Lec_id, lecs.Lec_name, lecs.Lec_Course)!=EOF) {

		if (lec_id == lecs.Lec_id) {
			printf("Assign course:");
			scanf("%s", course);
			strcpy(lecs.Lec_Course, course);
			
		}

		fprintf(temp, "%d %s %s\n", lecs.Lec_id, lecs.Lec_name, lecs.Lec_Course);
	}
	fclose(LF);
	fclose(temp);
	remove("Lecturers.txt");
	rename("Temp.txt", "Lecturers.txt");
}

/// //////////////////////////////////////////////////////////////

void update_users_password() {
	int ID;
	char password[20];
	FILE*UF = fopen("Users.txt", "r");
	FILE*Tem = fopen("Tem.txt", "w");
	struct User users;
	printf("which user password you wanted to update, Enter ID in interger:\n");
	scanf("%d", &ID);



	while (fscanf(UF, "%d %s %s %s", &users.id, users.username, users.password, users.usertype) != EOF) {
		
		if (ID == users.id) {
			printf("Update password:");
			scanf("%s", password);
			while (existance_password_check(UF, password) == 0) {
				printf("Update password:");
				scanf("%s", password);
				
			}
			strcpy(users.password, password);
			
		}

		

		
		fprintf(Tem,"%d %s %s %s\n", users.id, users.username, users.password, users.usertype);
	}
	fclose(UF);
	fclose(Tem);
	remove("Users.txt");
	rename("Tem.txt", "Users.txt");
	
}

///////////////////////////////////////////////////////////////////////////////////////////////////////

void STUDENT(struct User *users) {

	int exit,option,function;
	exit = 1;
	
	printf("Welcome %s\n", users->username);
	while (exit==1 ) {
		function = 1;
		printf("--------------------------------------\n");
		printf("Student Menu\n");
		printf("1. Std_View_enrolled_Course\n2. View personal detail\n3. View and Update personal detail\n4. View attendance\n");
		printf("--------------------------------------\n");
		scanf("%d", &option);
		getchar();
		system("cls");

		switch (option) {
		case 1:
			
			while (function == 1) {
				printf("Std_View_enrolled_Course\n");
				Std_view_enrolled_course(users->id);
				printf("\n");
				printf("Do you want to exit Std_View_enrolled_Course?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
				system("cls");
			}
			break;
		case 2:

			while (function == 1) {
				display_std_detail(users->id);
				printf("\n");
				printf("Do you want to exit View personal detail?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
				system("cls");
			}
			break;

		case 3:
			while (function == 1) {
				printf("\n");
				update_std_detail(users->id);
				printf("Do you want to exit View and Update personal detail?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
				system("cls");
			}
			break;
		case 4:
			while (function == 1) {
				printf("\n");
				display_attendance(users->id);
				printf("Do you want to exit View attendance?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
				system("cls");
			}
			break;
		default:
			printf("Invalid choice. Please try again.\n");
			break;
		}
		
		printf("Do you want to exit the program?\n1. No\n2. Yes\n");
		printf("Enter your choice: ");
		scanf("%d", &exit);
		system("cls");

	}
	

}

void SYSTEM_ADMINISTRATOR(struct User* users) {/////////////constructing

	int exit, option, function;
	exit = 1;
	printf("Welcome %s\n", users->username);

	while (exit==1) {
		function = 1;
		printf("--------------------------------------\n");
		printf("System Adminstrator Menu\n");
		printf("1. Generate reports\n2. Register users\n3. Define Grades\n4. Update password\n ");
		printf("--------------------------------------\n");
		printf("Option:");
		scanf("%d", &option);
		getchar();
		system("cls");

		switch (option) {
		case 1:

			while (function == 1) {
				system("cls");
				generate_report();
				printf("\n");
				printf("Do you want to exit Generate reports?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
				system("cls");
			}
			break;
		case 2:

			while (function == 1) {
				system("cls");
				register_user();
				printf("\n");
				printf("Do you want to exit Register?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
				system("cls");
			}
			break;
		case 3:

			while (function == 1) {
				system("cls");
				define_grades();
				printf("\n");
				printf("Do you want to exit Define grades?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
				system("cls");
			}
			break;
		case 4:
			while (function == 1) {
				system("cls");
				update_users_password();
				printf("\n");
				printf("Do you want to exit update password?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
				system("cls");
			}
			break;
			
		default:
			printf("Invalid choice. Please try again.\n");
			break;
		}

		printf("Do you want to exit the program?\n1. No\n2. Yes\n");
		printf("Enter your choice:");
		scanf("%d", &exit);
		system("cls");

	}

}


void LECTURER(struct User* users) {/////////////constructing

	int exit, option, function;
	exit = 1;
	printf("Welcome %s\n", users->username);

	while (exit == 1) {
		function = 1;
		printf("--------------------------------------\n");
		printf("Lecturer Menu\n");
		printf("1.update_mark \n2.View and update attendance\n ");
		printf("--------------------------------------\n");
		printf("Option:");
		scanf("%d", &option);
		getchar();
		system("cls");

		switch (option) {
		case 1:

			while (function == 1) {
				system("cls");
				update_marks();
				printf("\n");
				printf("Do you want to exit update_mark?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
				system("cls");
			}
			break;
		case 2:

			while (function == 1) {
				system("cls");
				attendance_record();
				printf("\n");
				printf("Do you want to exit View and update attendance?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
				system("cls");
			}
			break;
		default:
			printf("Invalid choice. Please try again.\n");
			break;
		}

		printf("Do you want to exit the program?\n1. No\n2. Yes\n");
		printf("Enter your choice:");
		scanf("%d", &exit);
		system("cls");

	}

}


void PROGRAMME_ADMINISTRATOR(struct User*users) {

	int exit, option, function;
	exit = 1;
	function = 1;
	printf("Welcome %s\n", users->username);

	while (exit == 1) {
		function = 1;
		printf("--------------------------------------\n");
		printf("Programme Administrator Menu\n");
		printf("1.assign lecturer course\n2.Enrol student course\n3.View and update specific course detail\n ");
		printf("--------------------------------------\n");
		printf("Option:");
		scanf("%d", &option);
		getchar();
		system("cls");

		switch (option) {
		case 1:

			while (function == 1) {
				system("cls");
				assign_lecturer_course();
				printf("\n");
				printf("Do you want to exit assign lecturer course?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
			}
			break;
		case 2:

			while (function == 1) {
				system("cls");
				update_course();
				printf("\n");
				printf("Do you want to exit Enrol student course?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
			}
			break;
		case 3:

			while (function == 1) {
				system("cls");
				Update_Course_detail();
				printf("\n");
				printf("Do you want to exit View and update specific course detail?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
			}
			break;

		case 4:

			while (function == 1) {
				printf("\n");
				Course_add();
				printf("Do you want to exit adding course?\n1. No\n2. Yes\n");
				printf("Enter your choice: ");
				scanf("%d", &function);
			}
		default:
			printf("Invalid choice. Please try again.\n");
			break;
		}

		printf("Do you want to exit the program?\n1. No\n2. Yes\n");
		printf("Enter your choice:");
		scanf("%d", &exit);

	}

}


void Course_add() {
	FILE* file = fopen("Courses.txt", "a+");

	if (file == NULL) {
		printf("Error opening file.\n");
		return;
	}

	struct Courses_detail Course;

	printf("Enter course code (integer number): ");
	scanf("%d", &Course.Course_code);

	printf("Enter course name: ");
	scanf("%s", Course.course_name);

	printf("Enter number of students: ");
	scanf("%d", &Course.course_student_quan);

	fprintf(file, "%d %s %d\n", Course.Course_code,  Course.course_name, Course.course_student_quan);

	fclose(file);

	printf("New course added successfully.\n");
}

void Update_Course_detail() {

	display_course_file();
	printf("\n");
	struct Courses_detail Course;

	int code,option,quantity;
	char course[50];

	FILE* file = fopen("Courses.txt", "r");
	FILE* tempo = fopen("temporary_course_detail.txt", "w");

	printf("Updating Course Detail\n");
	printf("Enter course code to target update (integer number):");
	scanf("%d", &code);
	getchar();

	while (fscanf(file, "%d %s %d", &Course.Course_code, Course.course_name, &Course.course_student_quan)!=EOF) {

		if (code == Course.Course_code) {
			system("cls");
			display_course_specific(Course.Course_code);
			printf("1.Update course name\n2.Update student quantity\n");
			printf("Enter option:\n");
			scanf("%d", &option);
			getchar();

			switch (option){

			case 1:
				printf("New course name:");
				scanf("%s", course);
				strcpy(Course.course_name, course);
				break;

			case 2:
				printf("Students quantity:\n");
				scanf("%d", &quantity);
				Course.course_student_quan = quantity;
				break;
			default:
				break;
			}
		}
		fprintf(tempo,"%d %s %d\n", Course.Course_code, Course.course_name, Course.course_student_quan);
	}

	fclose(file);
	fclose(tempo);

	remove("Courses.txt");
	rename("temporary_course_detail.txt","Courses.txt");

}

void display_course_file(){

	struct Courses_detail Course;

	FILE* CF = fopen("Courses.txt", "r");
	printf("Course || Student quantity");
	while (fscanf(CF, "%d %s %d",&Course.Course_code, Course.course_name, &Course.course_student_quan) != EOF) {

		printf("%d %s %d\n",Course.Course_code, Course.course_name, Course.course_student_quan);
	}
	fclose(CF);

}

void display_course_specific(int code) {
	struct Courses_detail Course;

	FILE* CF = fopen("Courses.txt", "r");

	while (fscanf(CF, "%d %s %d", &Course.Course_code, Course.course_name, &Course.course_student_quan) != EOF) {
		if (code == Course.Course_code) {
			printf("%d %s %d\n", Course.Course_code, Course.course_name, Course.course_student_quan);
		}
		
	}
	fclose(CF);

}



void update_std_detail(int ID) {

	display_std_detail(ID);
	printf("\n");
	int id, age, year;
	char name[50], course1[50], course2[50], course3[50];

	int prompt_age, prompt_year;
	char prompt_name[50];

	FILE* STD_DETAIL;
	STD_DETAIL = fopen("Student_Detail_File.txt", "r");
	FILE* STD_TEM;
	STD_TEM = fopen("STD_TEM.txt", "w");
	int option;

	rewind(STD_DETAIL);
	while (fscanf(STD_DETAIL, "%d %s %d %d %s %s %s", &id, name, &age, &year, course1, course2, course3) != EOF) {

		if (ID == id) {
			printf("What detail you wanted to update!\n1. Age \n2. Year \n3.name\n");
			scanf("%d",&option );

			switch (option) {

			case 1:
				printf("Age:");
				scanf("%d", &prompt_age);
				age = prompt_age;
				break;
			case 2:
				printf("Year:");
				scanf("%d", &prompt_year);
				year= prompt_year;
				break;
			case 3:
				printf("Name:");
				strcpy(name , prompt_name);
				break;
			}
		}
		fprintf(STD_TEM,"%d  %s  %d  %d  %s  %s  %s\n", id, name, age, year, course1, course2, course3);
	}

	fclose(STD_DETAIL);
	fclose(STD_TEM);
	remove("Student_Detail_File.txt");
	rename("STD_TEM.txt", "Student_Detail_File.txt");
}


void display_attendance_all() {
	
	struct attendance attend;

	FILE* AF;
	AF = fopen("attendance.txt", "r");


	printf("ID | Name | Course 1   | Course 2   | Course 3  \n ");
	while (fscanf(AF, "%d %s %s %d %d %s %d %d %s %d %d", &attend.id, attend.name, attend.attendance.course[0], &attend.attendance.attend[0], &attend.attendance.absent[0], attend.attendance.course[1], &attend.attendance.attend[1], &attend.attendance.absent[1], attend.attendance.course[2], &attend.attendance.attend[2], &attend.attendance.absent[2]) != EOF) {
		

		printf("%d | %s  | %s  Present:%d   Absent:%d  | %s  Present:%d   Absent:%d | %s  Present:%d   Absent:%d\n", attend.id, attend.name, attend.attendance.course[0], attend.attendance.attend[0], attend.attendance.absent[0], attend.attendance.course[1], attend.attendance.attend[1], attend.attendance.absent[1], attend.attendance.course[2], attend.attendance.attend[2], attend.attendance.absent[2]);
			

	}
	fclose(AF);
}

void display_attendance( int ID) {
	
	struct attendance attend;

	FILE* AF = fopen("attendance.txt","r");
	printf("ID | Name | Course 1   | Course 2  | Course 3 \n");
	while (fscanf(AF, "%d %s %s %d %d %s %d %d %s %d %d", &attend.id, attend.name, attend.attendance.course[0], &attend.attendance.attend[0], &attend.attendance.absent[0], attend.attendance.course[1], &attend.attendance.attend[1], &attend.attendance.absent[1], attend.attendance.course[2], &attend.attendance.attend[2], &attend.attendance.absent[2]) != EOF) {
		if (ID == attend.id) {

			printf("%d | %s  | %s  Present:%d   Absent:%d  | %s  Present:%d   Absent:%d | %s  Present:%d   Absent:%d\n", attend.id, attend.name, attend.attendance.course[0], attend.attendance.attend[0], attend.attendance.absent[0], attend.attendance.course[1], attend.attendance.attend[1], attend.attendance.absent[1], attend.attendance.course[2], attend.attendance.attend[2], attend.attendance.absent[2]);
			break;
		}

	}
	fclose(AF);

}


void Attendance(char response,struct attendance * attend,int x) {
	
		if (response == 'P' || response == 'p') {
			attend->attendance.attend[x]++;
		}
		else if (response == 'A' || response == 'a') {
			attend->attendance.absent[x]++;
		}
		else {
			printf("Invalid Attendance Character.");
		}
	
}

void attendance_record() {

	display_attendance_all();

	struct attendance attend;
	FILE* AF;
	AF = fopen("attendance.txt", "r");

	FILE* TEM;
	TEM = fopen("Temporary_att.txt", "w");
	int x;
	int ID;
	char target_course[50];
	char at;

	printf("Enter student ID: ");
	scanf("%d", &ID);


	while (fscanf(AF, "%d %s %s %d %d %s %d %d %s %d %d", &attend.id, attend.name, attend.attendance.course[0], &attend.attendance.attend[0], &attend.attendance.absent[0], attend.attendance.course[1], &attend.attendance.attend[1], &attend.attendance.absent[1], attend.attendance.course[2], &attend.attendance.attend[2], &attend.attendance.absent[2]) != EOF) {
		if (ID == attend.id) {
			printf("which course to update attendance:");
			scanf("%s", target_course);
			for (x = 0; x < 3; x++) {
				if (strcmp(target_course, attend.attendance.course[x]) == 0) {
					printf("A.Absent\nP.Present\n");
					printf("Enter:");
					scanf(" %c", &at);
					Attendance(at, &attend, x);
					break;
				}
			}

		}
		fprintf(TEM, "%d %s %s %d %d %s %d %d %s %d %d\n", attend.id, attend.name, attend.attendance.course[0], attend.attendance.attend[0], attend.attendance.absent[0], attend.attendance.course[1], attend.attendance.attend[1], attend.attendance.absent[1], attend.attendance.course[2], attend.attendance.attend[2], attend.attendance.absent[2]);
	}


	fclose(AF);
	fclose(TEM);
	remove("attendance.txt");
	rename("Temporary_att.txt", "attendance.txt");
	printf("Updated record check it!\n");
	display_attendance(ID);
}

