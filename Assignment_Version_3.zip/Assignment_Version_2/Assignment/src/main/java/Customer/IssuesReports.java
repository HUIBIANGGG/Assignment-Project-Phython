/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Customer;

import java.time.LocalDate;

/**
 *
 * @author User
 */
public class IssuesReports {
    private String Name; private String HallId; private LocalDate Date; private String Issue;
    
    public IssuesReports (String HallId, String Name, LocalDate Date, String Issue) {
        this.Name = Name;
        this.HallId = HallId;
        this.Date = Date;
        this.Issue = Issue;
    }

    public String getHallId() {
        return HallId;
    }

    public void setHallId(String HallId) {
        this.HallId = HallId;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public LocalDate getDate() {
        return Date;
    }

    public void setDate(LocalDate Date) {
        this.Date = Date;
    }

    public String getIssue() {
        return Issue;
    }

    public void setIssue(String Issue) {
        this.Issue = Issue;
    }
    
    
}
