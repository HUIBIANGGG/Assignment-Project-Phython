/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Customer;
import java.time.LocalDate;
import java.time.LocalTime;
/**
 *
 * @author User
 */
public class BookingsHistoryRecords {

    private String CustomerName; private String HallId; private String HallType; private LocalDate StartDate; 
    private LocalDate EndDate; private LocalTime StartTime; private LocalTime EndTime; 
    private String HallActivity; private double BookingRate; private String HallSeats; private double TotalPrice;

    public BookingsHistoryRecords(String CustomerName, String HallId, String HallType, LocalDate StartDate, LocalDate EndDate, LocalTime StartTime, LocalTime EndTime, String HallActivity, double BookingRate, String HallSeats, double TotalPrice) {
        this.CustomerName = CustomerName;
        this.HallId = HallId;
        this.HallType = HallType;
        this.StartDate = StartDate;
        this.EndDate = EndDate;
        this.StartTime = StartTime;
        this.EndTime = EndTime;
        this.HallActivity = HallActivity;
        this.BookingRate = BookingRate;
        this.HallSeats = HallSeats;
        this.TotalPrice = TotalPrice;
    }

    public String getCustomerName() {
        return CustomerName;
    }

    public void setCustomerName(String CustomerName) {
        this.CustomerName = CustomerName;
    }
    
    public String getHallId() {
        return HallId;
    }

    public void setHallId(String HallId) {
        this.HallId = HallId;
    }

    public String getHallType() {
        return HallType;
    }

    public void setHallType(String HallType) {
        this.HallType = HallType;
    }

    public LocalDate getStartDate() {
        return StartDate;
    }

    public void setStartDate(LocalDate StartDate) {
        this.StartDate = StartDate;
    }

    public LocalDate getEndDate() {
        return EndDate;
    }

    public void setEndDate(LocalDate EndDate) {
        this.EndDate = EndDate;
    }

    public LocalTime getStartTime() {
        return StartTime;
    }

    public void setStartTime(LocalTime StartTime) {
        this.StartTime = StartTime;
    }

    public LocalTime getEndTime() {
        return EndTime;
    }

    public void setEndTime(LocalTime EndTime) {
        this.EndTime = EndTime;
    }

    public String getHallActivity() {
        return HallActivity;
    }

    public void setHallActivity(String HallActivity) {
        this.HallActivity = HallActivity;
    }

    public double getBookingRate() {
        return BookingRate;
    }

    public void setBookingRate(double BookingRate) {
        this.BookingRate = BookingRate;
    }

    public String getHallSeats() {
        return HallSeats;
    }

    public void setHallSeats(String HallSeats) {
        this.HallSeats = HallSeats;
    }

    public double getTotalPrice() {
        return TotalPrice;
    }

    public void setTotalPrice(double TotalPrice) {
        this.TotalPrice = TotalPrice;
    }
    
    
}
