/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Customer;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

/**
 *
 * @author User
 */
public class txtFile4 {
    public void Write2file(Object myData) {

        try{
            IssuesReports Temp = (IssuesReports)myData;
            File FInput = new File("IssuesReport.txt");
            FileWriter fw = new FileWriter(FInput, true);
            PrintWriter pw = new PrintWriter(fw);
            String Name = Temp.getName();
            String HallId = Temp.getHallId();
            LocalDate Date = Temp.getDate();            
            String Issue = Temp.getIssue();
            String Line = Name + "|" + HallId + "|" + Date + "|" + Issue + "\n";           
            pw.write(Line);
            pw.close();
            System.out.println("Data Written Successfully");
        }
        catch(IOException Ex) {
            System.out.println("File Write Error.........");
        }
    }
}
