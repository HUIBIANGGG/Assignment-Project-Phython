/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Customer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;


public class txtFile2 {

    public ArrayList<BookingsHistoryRecords> myBookingsHistoryList = new ArrayList<BookingsHistoryRecords>();
    
    public void Write2file(Object myData) {

        try{
            BookingsHistoryRecords Temp = (BookingsHistoryRecords)myData;
            File FInput = new File("BookingsHistory.txt");
            FileWriter fw = new FileWriter(FInput, true);
            PrintWriter pw = new PrintWriter(fw);
            String CustomerName = Temp.getCustomerName();
            String HallId = Temp.getHallId();
            String HallType = Temp.getHallType();
            LocalDate StartDate = Temp.getStartDate();
            LocalDate EndDate = Temp.getEndDate();
            LocalTime StartTime = Temp.getStartTime();
            LocalTime EndTime = Temp.getEndTime();
            String HallActivity = Temp.getHallActivity();
            double BookingRate = Temp.getBookingRate();
            String HallSeats = Temp.getHallSeats();
            double TotalPrice = Temp.getTotalPrice();
            String Line = CustomerName + "," + HallId + "," + HallType + "," + StartDate +  "," + EndDate +
                    "," + StartTime + "," + EndTime + "," + HallActivity + "," + BookingRate + "," + HallSeats +"," + TotalPrice +"\n"; 
            pw.write(Line);
            pw.close();
            System.out.println("Data Written Successfully");
        }
        catch(IOException Ex) {
            System.out.println("File Write Error.........");
        }
    }
    
    public ArrayList<BookingsHistoryRecords> ReadFromFile(String fname) {
        try{
            myBookingsHistoryList.clear();
            String line;
            FileReader fileReader = new FileReader(fname);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
        
            while ((line = bufferedReader.readLine()) != null) {
                String[] dataRow = line.split(","); 

                String customername = dataRow[0];
                String hallId = dataRow[0].trim();
                String hallType = dataRow[1];
                LocalDate startDate = LocalDate.parse(dataRow[2].trim());
                LocalDate endDate = LocalDate.parse(dataRow[3].trim());
                LocalTime startTime = LocalTime.parse(dataRow[4].trim());  
                LocalTime endTime = LocalTime.parse(dataRow[5].trim());    
                String hallActivity = dataRow[6];
                double bookingRate = Double.parseDouble(dataRow[7].trim()); 
                String hallSeats = dataRow[8].trim();
                double totalPrice = Double.parseDouble(dataRow[9].trim());


                BookingsHistoryRecords temp = new BookingsHistoryRecords(customername, hallId, hallType, startDate, endDate, startTime, endTime, hallActivity, bookingRate, hallSeats, totalPrice);
                myBookingsHistoryList.add(temp);
            }
        
            bufferedReader.close();
        } catch (IOException ex) {
            System.out.println("File Read Error..................");
        } catch (NumberFormatException ex) {
            System.out.println("Error parsing numeric data: " + ex.getMessage());
        } catch (Exception ex) {
            System.out.println("Unexpected error: " + ex.getMessage());
        }
        return myBookingsHistoryList;
    }
}
