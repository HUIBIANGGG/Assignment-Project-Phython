/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Customer;
import java.time.LocalDate;
import java.time.LocalTime;
/**
 *
 * @author User
 */
public class BookingRecords {

    private String HallId; private String HallType; private LocalDate OpenDate; 
    private LocalDate CloseDate; private LocalTime OpenTime; private LocalTime CloseTime; 
    private double BookingRate; private String HallSeats;

    public BookingRecords(String HallId, String HallType, LocalDate OpenDate, LocalDate CloseDate, LocalTime OpenTime, LocalTime CloseTime, double BookingRate, String HallSeats) {
        this.HallId = HallId;
        this.HallType = HallType;
        this.OpenDate = OpenDate;
        this.CloseDate = CloseDate;
        this.OpenTime = OpenTime;
        this.CloseTime = CloseTime;
        this.BookingRate = BookingRate;
        this.HallSeats = HallSeats;
    }
    

    public String getHallId() {
        return HallId;
    }

    public void setHallId(String HallId) {
        this.HallId = HallId;
    }

    public String getHallType() {
        return HallType;
    }

    public void setHallType(String HallType) {
        this.HallType = HallType;
    }

    public LocalDate getOpenDate() {
        return OpenDate;
    }

    public void setOpenDate(LocalDate OpenDate) {
        this.OpenDate = OpenDate;
    }

    public LocalDate getCloseDate() {
        return CloseDate;
    }

    public void setCloseDate(LocalDate CloseDate) {
        this.CloseDate = CloseDate;
    }

    public LocalTime getOpenTime() {
        return OpenTime;
    }

    public void setOpenTime(LocalTime OpenTime) {
        this.OpenTime = OpenTime;
    }

    public LocalTime getCloseTime() {
        return CloseTime;
    }

    public void setCloseTime(LocalTime CloseTime) {
        this.CloseTime = CloseTime;
    }

    public double getBookingRate() {
        return BookingRate;
    }

    public void setBookingRate(double BookingRate) {
        this.BookingRate = BookingRate;
    }

    public String getHallSeats() {
        return HallSeats;
    }

    public void setHallSeats(String HallSeats) {
        this.HallSeats = HallSeats;
    }
    
    
}
