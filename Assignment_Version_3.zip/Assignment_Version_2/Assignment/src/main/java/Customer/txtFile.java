/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Customer;

import java.util.ArrayList;
import java.io.*;
import javax.swing.JOptionPane;

public class txtFile {
    
    public ArrayList<CustomerDetailsRecords> myCustomerList = new ArrayList<CustomerDetailsRecords>();
    
    public void Write2file(Object myData) {

        try{
            CustomerDetailsRecords Temp = (CustomerDetailsRecords)myData;
            File FInput = new File("CustomerDetails.txt");
            FileWriter fw = new FileWriter(FInput, true);
            PrintWriter pw = new PrintWriter(fw);
            
            
            File FInput_L = new File("UserInfo.txt");
            FileWriter fw_L = new FileWriter(FInput_L, true);
            PrintWriter pw_L = new PrintWriter(fw_L);
            
            String CustomerName = Temp.getCustomerName();
            String Password = Temp.getPassword();
            String EmailAddress = Temp.getEmailAddress();            
            String PhoneNumber = Temp.getPhoneNumber();
            
            String Line = CustomerName + "," + Password + "," + EmailAddress + "," + PhoneNumber + "\n";   
            String Line_1 = CustomerName + "," + "Customer" + ","+Password +"\n";
            
            pw.write(Line);
            pw_L.write(Line_1);
            pw.close();
            pw_L.close();
            System.out.println("Data Written Successfully");
        }
        catch(IOException Ex) {
            System.out.println("File Write Error.........");
        }
    }
    
    public ArrayList<CustomerDetailsRecords> ReadFromFile(String fname) {
        try{
            myCustomerList.clear(); String line;
            FileReader fileReader = new FileReader(fname);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            while ((line = bufferedReader.readLine())!=null) {
                Object[] CustomerLine = line.lines().toArray();
                for (int i=0; i<CustomerLine.length; i++) {
                    String Line = CustomerLine[i].toString().trim();
                    String[] dataRow = Line.split(",");
                    CustomerDetailsRecords Temp = new CustomerDetailsRecords(dataRow[0], dataRow[1], dataRow[2], dataRow[3]);
                    myCustomerList.add(Temp);
                    Temp = null;
                    
                }
            }
            bufferedReader.close();
        }
        catch(IOException Ex){
            System.out.println("File Read Error..................");
        }
        
        return myCustomerList;
    }
    
    public void Write2file2(String fname, ArrayList<CustomerDetailsRecords> customers) {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname))) {
            for (CustomerDetailsRecords customer : customers) {
                String line = customer.getCustomerName() + "," +
                              customer.getPassword() + "," +
                              customer.getEmailAddress() + "," +
                              customer.getPhoneNumber();
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
}
