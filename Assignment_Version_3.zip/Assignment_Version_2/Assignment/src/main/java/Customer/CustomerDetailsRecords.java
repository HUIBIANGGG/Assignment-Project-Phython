/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Customer;


public class CustomerDetailsRecords {
  
    private String CustomerName; private String Password; private String EmailAddress; private String PhoneNumber;

    public CustomerDetailsRecords(String CustomerName, String Password, String EmailAddress, String PhoneNumber) {
        this.CustomerName = CustomerName;
        this.Password = Password;
        this.EmailAddress = EmailAddress;
        this.PhoneNumber = PhoneNumber;
    }

    public String getCustomerName() {
        return CustomerName;
    }

    public void setCustomerName(String CustomerName) {
        this.CustomerName = CustomerName;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public String getEmailAddress() {
        return EmailAddress;
    }

    public void setEmailAddress(String EmailAddress) {
        this.EmailAddress = EmailAddress;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
   
}
