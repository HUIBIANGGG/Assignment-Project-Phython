/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Customer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class txtFile3 {
    public ArrayList<BookingRecords> myBookingsList = new ArrayList<BookingRecords>();
    
    public void Write2file(Object myData) {

        try{
            BookingRecords Temp = (BookingRecords)myData;
            File FInput = new File("Bookings.txt");
            FileWriter fw = new FileWriter(FInput, true);
            PrintWriter pw = new PrintWriter(fw);
            String HallId = Temp.getHallId();
            String HallType = Temp.getHallType();
            LocalDate OpenDate = Temp.getOpenDate();
            LocalDate CloseDate = Temp.getCloseDate();
            LocalTime OpenTime = Temp.getOpenTime();
            LocalTime CloseTime = Temp.getCloseTime();
            double BookingRate = Temp.getBookingRate();
            String HallSeats = Temp.getHallSeats();
            String Line = HallId + "," + HallType + "," + OpenDate +  "," + CloseDate +
                    "," + OpenTime + "," + CloseTime + "," + BookingRate + "," + HallSeats +"\n"; 
            pw.write(Line);
            pw.close();
            System.out.println("Data Written Successfully");
        }
        catch(IOException Ex) {
            System.out.println("File Write Error.........");
        }
    }
    
    public ArrayList<BookingRecords> ReadFromFile(String fname) {
        try{
            myBookingsList.clear();
            String line;
            FileReader fileReader = new FileReader(fname);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
        
            while ((line = bufferedReader.readLine()) != null) {
                String[] dataRow = line.split(","); 

                String hallId = dataRow[0].trim();
                String hallType = dataRow[1].trim();
                LocalDate openDate = LocalDate.parse(dataRow[2].trim());
                LocalDate closeDate = LocalDate.parse(dataRow[3].trim());
                LocalTime openTime = LocalTime.parse(dataRow[4].trim());  
                LocalTime closeTime = LocalTime.parse(dataRow[5].trim());    
                double bookingRate = Double.parseDouble(dataRow[6].trim()); 
                String hallSeats = dataRow[7].trim();


                BookingRecords temp = new BookingRecords(hallId, hallType, openDate, closeDate, openTime, closeTime, bookingRate, hallSeats);
                myBookingsList.add(temp);
            }
        
            bufferedReader.close();
        } catch (IOException ex) {
            System.out.println("File Read Error..................");
        } catch (NumberFormatException ex) {
            System.out.println("Error parsing numeric data: " + ex.getMessage());
        } catch (Exception ex) {
            System.out.println("Unexpected error: " + ex.getMessage());
        }
        return myBookingsList;
    }
}
