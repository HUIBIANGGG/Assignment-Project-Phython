/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacourse.assignment;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
/////// owned hall
/////// schedule
////// maintainance

public class Write {
   
    
    
    public String Schedule_Write(Object Y){
         Schedule sch = (Schedule) Y;
         String strt = sch.getStartDate();
         String end = sch.getEndDate();
         String strtTime = sch.getStartTime();
         String endTime = sch.getEndTime();
         String remarks = sch.getRemarks();
         return strt+","+end+","+strtTime+","+endTime+","+remarks;
    }
    
  
    
    public void Write(Object X,int ObjectChoices,Object Y) throws IOException {/////////////receiving objects
        File fl = new File("OwnedHall.txt");
        FileWriter fw = new FileWriter(fl,true);
        PrintWriter pw = new PrintWriter(fw);
        
        
        
        switch(ObjectChoices){
            
            case 1:
                Auditorium Audi = (Auditorium)X;
                
                String AudiName = Audi.getName();
                String ScheWAudi = Schedule_Write(Y);
                String Audiwriting = "\n"+AudiName+","+ Audi.getHallType()+","+ScheWAudi+","+Audi.getBookingRatePerHour()+","+Audi.getSeats();
                pw.write(Audiwriting);
                pw.close();
                break;
            case 2:
                BanquetHall Ban =(BanquetHall)X;
                
                String BanName = Ban.getName();
                String ScheWBan = Schedule_Write(Y);
                String Banwriting = "\n"+BanName+","+ Ban.getHallType()+","+ScheWBan+","+Ban.getBookingRatePerHour()+","+Ban.getSeats();
                pw.write(Banwriting);
                pw.close();
                break;
            case 3:
                MeetingRoom Mer = (MeetingRoom)X;
                String MerName = Mer.getName();
                String ScheWMeet = Schedule_Write(Y);
                String Merwriting = "\n"+MerName+","+ Mer.getHallType()+","+ScheWMeet+","+Mer.getBookingRatePerHour()+","+Mer.getSeats();
                pw.write(Merwriting);
                pw.close();

                break;
        }
        
      
      
       
       
        
       
       
    }
    
    public void write_updated(String File,ArrayList<ReadData> Readed) throws IOException{
        FileWriter fw = new FileWriter(File);
        BufferedWriter Bfw= new BufferedWriter(fw);
        
        for (ReadData Line:Readed){
            Bfw.write(Line.toString());
            Bfw.newLine();
        }
        
         Bfw.close();
        
    }
    
    
    
   
    
}
