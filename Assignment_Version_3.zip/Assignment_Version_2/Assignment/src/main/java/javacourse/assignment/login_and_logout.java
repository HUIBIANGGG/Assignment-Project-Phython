/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacourse.assignment;

/**
 *
 * @author Owner
 */
public interface login_and_logout {
    
    public abstract void login(String filename,String username,String usertype, String password, Login currentLogin);
    public abstract void logout();
    
    
    
}

