/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacourse.assignment;


import Customer.Menu;
import Manager.Manager_Interface;
import administrator.MainMenu;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class User implements login_and_logout {
    private String username;
    private String userType;
    private String password;
    
    
    

    public User(String username, String userType, String password) {
        this.username = username;
        this.userType = userType;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    @Override
    public void login(String filename,String username,String usertype, String password, Login currentLogin){
        
        try {
            boolean Bool;
            Bool = readinguserinfo(filename,username, usertype,password);
            if (Bool == true){
                System.out.print("Logged in");
                switch(usertype){
                    case "Admin":
                        MainMenu MM = new MainMenu();
                        //Admin_Menu ADM = new Admin_Menu();
                        MM.setVisible(true);
                        break;
                    case "Customer":
                        Menu CM = new Menu(username);
                        CM.setVisible(true);
                        break;
                    case "Manager":
                        Manager_Interface MN = new Manager_Interface();
                        MN.setVisible(true);
                        break;
                    case "Scheduler":
                        Scheduler_Menu SM = new Scheduler_Menu();
                        SM.setVisible(true);
                        break;
                        
                }
              currentLogin.dispose();
            }
        } catch (IOException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void logout() {
        Login lg = new Login();
        lg.setVisible(true);
        
    }
    
  
     public boolean readinguserinfo(String filename,String username,String usertype, String password) throws IOException{
        Read rd =new Read();
        ArrayList<User> ArlRU = rd.ReadUser(filename);
        
        for (User line : ArlRU){
            
            if (line.getUsername().equals(username)&&line.getUserType().equals(usertype)&&line.getPassword().equals(password)){
                
                return true;
            }
            
        }
        return false;
    }     

  

}

        
        
    

