/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacourse.assignment;

public class Hall {
    private String hallType;
    private float bookingRatePerHour;
    private int seats;
  
   
    
    public Hall(float b,int s, String ht){
        bookingRatePerHour = b;
        seats = s;
        hallType= ht;
    }

    public String getHallType() {
        return hallType;
    }

    public void setHallType(String hallType) {
        this.hallType = hallType;
    }

    public float getBookingRatePerHour() {
        return bookingRatePerHour;
    }

    public void setBookingRatePerHour(float bookingRatePerHour) {
        this.bookingRatePerHour = bookingRatePerHour;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }
    
    public void displayHall(){
        System.out.println( bookingRatePerHour+" " + seats +hallType);
    }

    @Override
    public String toString() {
        return  hallType + "," + bookingRatePerHour + "," + seats;
    }
    
    


}

class Auditorium extends Hall{
    
    private String name= null;
    private Schedule schedule;
   
    public Auditorium(String n, Schedule sc){
        super(300.00f,1000,"Auditorium");
        name = n;
        schedule = sc;
    }
    
    public void displayInfo(){
        displayHall();
        System.out.println(name);
        schedule.scheduleDisplay();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Schedule getSchedule() {
        return schedule;
    }

    @Override
    public String toString() {
        return name+","+super.toString()+","+schedule ;
    }
    
    
    
}

class BanquetHall extends Hall{
    
    private String name;
    private Schedule schedule;
    public BanquetHall(String n ,Schedule sc){
        super(100.00f,300,"Banquet Hall");
        name = n;
        schedule = sc;
        
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Schedule getSchedule() {
        return schedule;
    }

    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
    }
    public String toString() {
        return name+","+super.toString()+","+schedule ;
    }
}

class MeetingRoom extends Hall{
    private String name;
    private Schedule schedule;
    public MeetingRoom(String n ,Schedule sc){
        super(50.00f,30,"Meeting Room");
        name = n;
        schedule = sc;
    }
    
      public String toString() {
        return name+","+super.toString()+","+ schedule ;
    }

    public String getName() {
        return name;
    }

    public Schedule getSchedule() {
        return schedule;
    }
    
   
     
}


////////////////////////////


 class ReadData{
    private String name;
    private String hallType;
    private String startDate;
    private String endDate;
    private String StartTime;
    private String EndTime;
    private String remarks;
    private String bookingRatePerHour;
    private String seats;

    public ReadData(String name, String hallType, String startDate, String endDate,String StartTime,String EndTime, String remarks, String bookingRatePerHour, String seats) {
        this.name = name;
        this.hallType = hallType;
        this.startDate = startDate;
        this.endDate = endDate;
        this.StartTime = StartTime;
        this.EndTime=EndTime;
        this.remarks = remarks;
        this.bookingRatePerHour = bookingRatePerHour;
        this.seats = seats;
    }
    
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHallType() {
        return hallType;
    }

    public void setHallType(String hallType) {
        this.hallType = hallType;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStartTime() {
        return StartTime;
    }

    public void setStartTime(String StartTime) {
        this.StartTime = StartTime;
    }

    public String getEndTime() {
        return EndTime;
    }

    public void setEndTime(String EndTime) {
        this.EndTime = EndTime;
    }
    
    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getBookingRatePerHour() {
        return bookingRatePerHour;
    }

    public void setBookingRatePerHour(String bookingRatePerHour) {
        this.bookingRatePerHour = bookingRatePerHour;
    }

    public String getSeats() {
        return seats;
    }

    public void setSeats(String seats) {
        this.seats = seats;
    }

    @Override
    public String toString() {
        return  name + "," + hallType + "," + startDate + "," + endDate + "," +StartTime+","+EndTime+ "," + remarks + "," + bookingRatePerHour + "," + seats;
    }
    
    
    
}