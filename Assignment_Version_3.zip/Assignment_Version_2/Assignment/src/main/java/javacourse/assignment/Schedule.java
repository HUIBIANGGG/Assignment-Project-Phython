/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacourse.assignment;

/**
 *
 * @author Owner
 */
public class Schedule {
    private String startDate=null;
    private String endDate= null;
    private String remarks = null;
     private String StartTime=null;
    private String EndTime=null;

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStartTime() {
        return StartTime;
    }

    public void setStartTime(String StartTime) {
        this.StartTime = StartTime;
    }

    public String getEndTime() {
        return EndTime;
    }

    public void setEndTime(String EndTime) {
        this.EndTime = EndTime;
    }
    
    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void scheduleDisplay(){
        System.out.print(startDate + endDate +remarks);
    }

    @Override
    public String toString() {
        return  startDate+","+ endDate +","+StartTime+","+EndTime+","+ remarks ;
    }
    
}
