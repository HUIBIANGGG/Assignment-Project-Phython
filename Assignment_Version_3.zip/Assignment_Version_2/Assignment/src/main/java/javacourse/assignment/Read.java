/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javacourse.assignment;

import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;


public class Read {
    String linestr;
    String[] lines;
    
  public ArrayList Reading(String filename) throws FileNotFoundException, IOException {
        
        File fl = new File(filename);
        FileReader rd = new FileReader(fl);
        BufferedReader bf = new BufferedReader(rd);
        
        ArrayList<ReadData> arl = new ArrayList<>();
        String linestr;
        
       
        while ((linestr = bf.readLine()) != null) {
            
            if (linestr.length() >= 4) {
                String[] lines = linestr.split(",");
               
              
                if (lines.length >=9) {
                    String name = lines[0];
                    String roomtype = lines[1];
                    String startDate = lines[2];
                    String endDate = lines[3];
                    String StartTime = lines[4];
                    String EndTime = lines[5];
                    String remarks = lines[6];
                    String price = lines[7];
                    String seat = lines[8];
                    
                    ReadData RDT = new ReadData(name,roomtype,startDate,endDate,StartTime,EndTime,remarks,price,seat);
                    
                    arl.add(RDT);
                   
                } else {
                    System.out.println("Invalid line format: " + linestr);
                }
                
            }
            
        }
        
        bf.close();
        return arl;
    }
  
  
   
   
   public ArrayList ReadUser(String filename) throws IOException{
       File fl = new File(filename);
        FileReader rd = new FileReader(fl);
        BufferedReader bf = new BufferedReader(rd);
        
        ArrayList<User> arl = new ArrayList<>();
        String linestr;
            
        
        while ((linestr = bf.readLine()) != null) {
            
            if (linestr.length() >= 4) {
                String[] lines = linestr.split(",");
               
              
                if (lines.length >=3) {
                    String name = lines[0];
                    String usertype = lines[1];
                    String password = lines[2];
                   
                    
                    User us = new User(name,usertype,password);
                    
                    arl.add(us);
                   
                } else {
                    System.out.println("Invalid line format: " + linestr);
                }
                
            }
            
        }
        
        bf.close();
        return arl;
   }

   
    
     
}
