/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package javacourse.assignment;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javacourse.assignment.Read;
import javacourse.assignment.ReadData;



public class Assignment {
    
   
    public static void main(String[] args) throws IOException  {
        //menuCustomer mCus = new menuCustomer();
        //Read r = new Read();
        //r.Reading();
        //mCus.AuditoriumWrite();
        //File cr = new File("MaintainanceFile.txt");
        //cr.createNewFile();
        //Clr.clr();
        Login Starting = new Login();
        Starting.setVisible(true);
      
        
    }
}
 