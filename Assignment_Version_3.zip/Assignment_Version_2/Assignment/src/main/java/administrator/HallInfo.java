/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package administrator;

public class HallInfo {
    private String HallID;
    private String HallName;
    private String HallLocation;

    public HallInfo(String HallID, String HallName, String HallLocation) {
        this.HallID = HallID;
        this.HallName = HallName;
        this.HallLocation = HallLocation;
    }

    public String getHallID() {
        return HallID;
    }

    public String getHallName() {
        return HallName;
    }

    public String getHallLocation() {
        return HallLocation;
    }

    public void setHallID(String HallID) {
        this.HallID = HallID;
    }

    public void setHallName(String HallName) {
        this.HallName = HallName;
    }

    public void setHallLocation(String HallLocation) {
        this.HallLocation = HallLocation;
    }

    @Override
    public String toString() {
        return "HallInfo{" + "HallID=" + HallID + ", HallName=" + HallName + ", HallLocation=" + HallLocation + '}';
    }
    
    
}
