/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package administrator;

public class Scheduler {
    private String SchID;
    private String SchName;
    private String SchEmail;
    private String SchContact;
    private String SchPosition;
    private String SchSalary;

    public Scheduler(String SchID, String SchName, String SchEmail, String SchContact, String SchPosition, String SchSalary) {
        this.SchID = SchID;
        this.SchName = SchName;
        this.SchEmail = SchEmail;
        this.SchContact = SchContact;
        this.SchPosition = SchPosition;
        this.SchSalary = SchSalary;
    }

    public String getSchID() {
        return SchID;
    }

    public String getSchName() {
        return SchName;
    }

    public String getSchEmail() {
        return SchEmail;
    }

    public String getSchContact() {
        return SchContact;
    }

    public String getSchPosition() {
        return SchPosition;
    }

    public String getSchSalary() {
        return SchSalary;
    }

    public void setSchID(String SchID) {
        this.SchID = SchID;
    }

    public void setSchName(String SchName) {
        this.SchName = SchName;
    }

    public void setSchEmail(String SchEmail) {
        this.SchEmail = SchEmail;
    }

    public void setSchContact(String SchContact) {
        this.SchContact = SchContact;
    }

    public void setSchPosition(String SchPosition) {
        this.SchPosition = SchPosition;
    }

    public void setSchSalary(String SchSalary) {
        this.SchSalary = SchSalary;
    }

    @Override
    public String toString() {
        return "Scheduler{" + "SchID=" + SchID + ", SchName=" + SchName + ", SchEmail=" + SchEmail + ", SchContact=" + SchContact + ", SchPosition=" + SchPosition + ", SchSalary=" + SchSalary + '}';
    }
    
    
    
    
}
