/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package administrator;

public class Customer {
    private String CustID;
    private String CustName;
    private String CustEmail;
    private String CustContact;

    public Customer(String CustID, String CustName, String CustEmail, String CustContact) {
        this.CustID = CustID;
        this.CustName = CustName;
        this.CustEmail = CustEmail;
        this.CustContact = CustContact;
    }

    public String getCustID() {
        return CustID;
    }

    public String getCustName() {
        return CustName;
    }

    public String getCustEmail() {
        return CustEmail;
    }

    public String getCustContact() {
        return CustContact;
    }

    public void setCustID(String CustID) {
        this.CustID = CustID;
    }

    public void setCustName(String CustName) {
        this.CustName = CustName;
    }

    public void setCustEmail(String CustEmail) {
        this.CustEmail = CustEmail;
    }

    public void setCustContact(String CustContact) {
        this.CustContact = CustContact;
    }

    @Override
    public String toString() {
        return "Customer{" + "CustID=" + CustID + ", CustName=" + CustName + ", CustEmail=" + CustEmail + ", CustContact=" + CustContact + '}';
    }
    
    
}
