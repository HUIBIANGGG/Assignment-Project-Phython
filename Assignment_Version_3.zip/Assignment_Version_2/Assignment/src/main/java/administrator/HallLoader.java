/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package administrator;
import java.io.*;
import java.util.ArrayList;

public class HallLoader {
     public static ArrayList<HallInfo> loadHallInfo(String filename) throws IOException {
        ArrayList<HallInfo> HallDetails = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;

        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length == 3) {
                String HallID = parts[0];
                String HallName = parts[1];
                String HallLocation = parts[2];
                HallDetails.add(new HallInfo(HallID, HallName, HallLocation));
            }
        }

        reader.close();
        return HallDetails;
    }
}
