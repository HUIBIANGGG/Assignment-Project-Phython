/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package administrator;
import javax.swing.table.DefaultTableModel;

public abstract class AbstractSearch {
    public abstract boolean search(String query, DefaultTableModel model);
}
