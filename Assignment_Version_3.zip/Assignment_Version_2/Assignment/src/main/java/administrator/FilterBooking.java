/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package administrator;


public class FilterBooking {
    private String CustName;
    private String ActivityName;
    private String BookingStartDate;
    private String BookingEndDate;
    private String TotalPaid;
    private String HallID;

    public FilterBooking(String CustName, String ActivityName, String BookingStartDate, String BookingEndDate, String TotalPaid, String HallID) {
        this.CustName = CustName;
        this.ActivityName = ActivityName;
        this.BookingStartDate = BookingStartDate;
        this.BookingEndDate = BookingEndDate;
        this.TotalPaid = TotalPaid;
        this.HallID = HallID;
    }

    public String getCustName() {
        return CustName;
    }

    public String getActivityName() {
        return ActivityName;
    }

    public String getBookingStartDate() {
        return BookingStartDate;
    }

    public String getBookingEndDate() {
        return BookingEndDate;
    }

    public String getTotalPaid() {
        return TotalPaid;
    }

    public String getHallID() {
        return HallID;
    }

    public void setCustName(String CustName) {
        this.CustName = CustName;
    }

    public void setActivityName(String ActivityName) {
        this.ActivityName = ActivityName;
    }

    public void setBookingStartDate(String BookingStartDate) {
        this.BookingStartDate = BookingStartDate;
    }

    public void setBookingEndDate(String BookingEndDate) {
        this.BookingEndDate = BookingEndDate;
    }

    public void setTotalPaid(String TotalPaid) {
        this.TotalPaid = TotalPaid;
    }

    public void setHallID(String HallID) {
        this.HallID = HallID;
    }

    @Override
    public String toString() {
        return "FilterBooking{" + "CustName=" + CustName + ", ActivityName=" + ActivityName + ", BookingStartDate=" + BookingStartDate + ", BookingEndDate=" + BookingEndDate + ", TotalPaid=" + TotalPaid + ", HallID=" + HallID + '}';
    }
    
    
    
}
