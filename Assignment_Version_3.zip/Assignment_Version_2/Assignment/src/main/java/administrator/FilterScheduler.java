/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package administrator;

public class FilterScheduler {
    private String SchedulerName;
    private String schedulerRole;
    private String Salary;
    private int YearsofExp;
    private String HallID;

    public FilterScheduler(String SchedulerName, String schedulerRole, String Salary, int YearsofExp, String HallID) {
        this.SchedulerName = SchedulerName;
        this.schedulerRole = schedulerRole;
        this.Salary = Salary;
        this.YearsofExp = YearsofExp;
        this.HallID = HallID;
    }

    public String getSchedulerName() {
        return SchedulerName;
    }

    public String getSchedulerRole() {
        return schedulerRole;
    }

    public String getSalary() {
        return Salary;
    }

    public int getYearsofExp() {
        return YearsofExp;
    }

    public String getHallID() {
        return HallID;
    }

    public void setSchedulerName(String SchedulerName) {
        this.SchedulerName = SchedulerName;
    }

    public void setSchedulerRole(String schedulerRole) {
        this.schedulerRole = schedulerRole;
    }

    public void setSalary(String Salary) {
        this.Salary = Salary;
    }

    public void setYearsofExp(int YearsofExp) {
        this.YearsofExp = YearsofExp;
    }

    public void setHallID(String HallID) {
        this.HallID = HallID;
    }


    @Override
    public String toString() {
        return "FilterScheduler{" + "SchedulerName=" + SchedulerName + ", schedulerRole=" + schedulerRole + ", Salary=" + Salary + ", YearsofExp=" + YearsofExp + ", HallID=" + HallID + '}';
    }
    
    
}
