/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package administrator;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.table.DefaultTableModel;

public class CustomerSearchByName extends AbstractSearch {
    
    public boolean search(String name, DefaultTableModel model) {
        boolean customerFound = false;

        model.setRowCount(0);

        try (BufferedReader br = new BufferedReader(new FileReader("src//administrator//CustomerInfo.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");

                if (parts[1].trim().equalsIgnoreCase(name)) {
                    model.addRow(new Object[]{parts[0], parts[1], parts[2], parts[3]});
                    customerFound = true;
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return customerFound;
    }
}
