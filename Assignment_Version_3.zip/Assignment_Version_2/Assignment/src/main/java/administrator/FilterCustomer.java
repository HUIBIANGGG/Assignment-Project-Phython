/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package administrator;

public class FilterCustomer {
    private String CustName;
    private String CustEmail;
    private int CustContact;
    private int CustTotalBooking;
    private String HallID;

    public FilterCustomer(String CustName, String CustEmail, int CustContact, int CustTotalBooking, String HallID) {
        this.CustName = CustName;
        this.CustEmail = CustEmail;
        this.CustContact = CustContact;
        this.CustTotalBooking = CustTotalBooking;
        this.HallID = HallID;
    }

    public String getCustName() {
        return CustName;
    }

    public String getCustEmail() {
        return CustEmail;
    }

    public int getCustContact() {
        return CustContact;
    }

    public int getCustTotalBooking() {
        return CustTotalBooking;
    }

    public String getHallID() {
        return HallID;
    }

    public void setCustName(String CustName) {
        this.CustName = CustName;
    }

    public void setCustEmail(String CustEmail) {
        this.CustEmail = CustEmail;
    }

    public void setCustContact(int CustContact) {
        this.CustContact = CustContact;
    }

    public void setCustTotalBooking(int CustTotalBooking) {
        this.CustTotalBooking = CustTotalBooking;
    }

    public void setHallID(String HallID) {
        this.HallID = HallID;
    }

    @Override
    public String toString() {
        return "FilterCustomer{" + "CustName=" + CustName + ", CustEmail=" + CustEmail + ", CustContact=" + CustContact + ", CustTotalBooking=" + CustTotalBooking + ", HallID=" + HallID + '}';
    }
    
    
}
