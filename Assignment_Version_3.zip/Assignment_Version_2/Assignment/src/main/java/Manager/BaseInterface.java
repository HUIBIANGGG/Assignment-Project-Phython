package Manager;

import java.awt.event.ActionEvent;
import javax.swing.JFrame;

public abstract class BaseInterface extends JFrame {

    public BaseInterface() {
        initCommonComponents();
    }

    protected abstract void loadDataFromFile();

    protected abstract void onExitAction(ActionEvent evt);

    protected void initCommonComponents() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
    }

    protected void navigateBackToManager() {
        this.dispose();
        new Manager_Interface().setVisible(true);
    }
}
